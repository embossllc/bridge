// @ts-nocheck
import Logo from '../../assets/images/ValueLife-Logo.svg';

export {Logo};
